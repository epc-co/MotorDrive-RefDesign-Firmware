/**
 * adc_compensation.c
 * 
 * ADC compensation
 * 
 * Component: ADC compensation
 */

/* *********************************************************************
 *
 * Motor Control Application Framework
 * R6/RC8 (commit 102056, build on 2020 Aug 25)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdint.h>
#include "util.h"
#include "adc_compensation.h"
#include "system_state.h"
#include "parameters/adc_params.h"
#include "hal.h"

void MCAF_ADCCompensationInit(MCAF_MOTOR_INITIALIZATION *pinit, 
                              MCAF_CURRENT_COMPENSATION_PARAMETERS *pcal)
{
    /* Scaling constants: Determined by calibration or hardware design. */
                   
    pcal->qKaa = CURRENT_KAA;
    pcal->qKab = CURRENT_KAB;         /* cross-axis gain compensation terms */
    pcal->qKba = CURRENT_KBA;         /* cross-axis gain compensation terms */
    pcal->qKbb = CURRENT_KBB;
    
    pinit->sampleCount = 0;
    pinit->sampleCountLimit = MCAF_CAL_COUNT;
    pinit->offsetLPF[0].x32 = 0;
    pinit->offsetLPF[1].x32 = 0;
    
    pinit->kfilter = MCAF_CAL_FILTER_GAIN;
}

inline void MCAF_ADCApplyCurrentCompensation(const MCAF_CURRENT_COMPENSATION_PARAMETERS *pcal,
                                             MC_ABC_T *piabc)
{
    // (these signs are correct: the opamps in our current sensing have a negative gain)
    const int16_t a1 = pcal->offseta - piabc->a;
    const int16_t b1 = pcal->offsetb - piabc->b;
    
    piabc->a =  (UTIL_mulss(a1, pcal->qKaa)
                +UTIL_mulss(b1, pcal->qKab)) >> 15;
    piabc->b =  (UTIL_mulss(a1, pcal->qKba)
                +UTIL_mulss(b1, pcal->qKbb)) >> 15;
}

/**
 * Reads ADC samples for current phases, auxiliary analog inputs,
 * and routes results to appropriate area in motor data structure.
 *
 * @param pmotor motor data
*/
void MCAF_ADCRead(MCAF_MOTOR_DATA *pmotor)
{
    pmotor->iabc.a = HAL_ADC_ValueIphaseA();
    pmotor->iabc.b = HAL_ADC_ValueIphaseB();
    
    MCAF_ADCApplyCurrentCompensation(&pmotor->currentCalibration, &pmotor->iabc);
    
    pmotor->potInput = HAL_ADC_UnsignedFromSignedInput(HAL_ADC_ValuePotentiometer());
    /* The default ADC result is bipolar with 0 counts =
     * the middle of the input voltage range.
     * VDC sensing is an exception to this rule.
     */
    uint16_t unipolarADCResult = HAL_ADC_UnsignedFromSignedInput(HAL_ADC_ValueDclink());
    pmotor->psys->vDC = unipolarADCResult >> 1;    
    pmotor->vDC = pmotor->psys->vDC;

    if (!MCAF_OverrideVelocityCommand(&pmotor->testing))
    {
        pmotor->velocityControl.velocityCmd = pmotor->velocityControl.velocityCmdApi;
    }
}

/**
 * Executes one step of current offset calibration.
 * During the calibration interval, integrates filtered offset
 * based on the compensated measurement value, but only if it is within
 * range.
 * 
 * @param pLPF pointer to low-pass-filter integrator
 * @param measurement compensated measurement
 * @param k integrator gain
 */
inline void MCAF_ADCCalibrateCurrentOffset(sx1632_t *pLPF, int16_t measurement, int16_t k)
{
    if ((measurement >= -MCAF_CAL_RANGE) && (measurement <= MCAF_CAL_RANGE))
    {
        pLPF->x32 += UTIL_mulss(measurement << MCAF_CAL_SHIFT, k);
    }
}

void MCAF_ADCCalibrateCurrentOffsets(MCAF_MOTOR_INITIALIZATION *pinit, 
                                     MCAF_CURRENT_COMPENSATION_PARAMETERS *pcal,
                                     const MCAF_U_CURRENT_ABC *piabc)
{
    if (pinit->sampleCount < pinit->sampleCountLimit)
    {
        MCAF_ADCCalibrateCurrentOffset(&pinit->offsetLPF[0], piabc->a, pinit->kfilter);
        MCAF_ADCCalibrateCurrentOffset(&pinit->offsetLPF[1], piabc->b, pinit->kfilter);
    
        pcal->offseta = pinit->offsetLPF[0].x16.hi >> MCAF_CAL_SHIFT;
        pcal->offsetb = pinit->offsetLPF[1].x16.hi >> MCAF_CAL_SHIFT;
        ++pinit->sampleCount;
    }
    else
    {
        pinit->ready = true;
    }
}

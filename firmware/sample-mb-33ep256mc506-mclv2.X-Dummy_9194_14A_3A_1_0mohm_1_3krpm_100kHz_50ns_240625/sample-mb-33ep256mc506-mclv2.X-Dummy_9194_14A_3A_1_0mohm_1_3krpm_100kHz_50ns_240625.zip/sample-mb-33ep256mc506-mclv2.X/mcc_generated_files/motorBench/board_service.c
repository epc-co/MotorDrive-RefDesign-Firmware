/**
 * board_service.c
 * 
 * Provides hardware-independent board service components with interfaces
 * extending into the HAL.
 * 
 * Component: HAL
 */

/* *********************************************************************
 * 
 * Motor Control Application Framework
 * R6/RC8 (commit 102056, build on 2020 Aug 25)
 *
 * (c) 2017 - 2020 Microchip Technology Inc. and its subsidiaries. You may use
 * this software and any derivatives exclusively with Microchip products.
 *
 * This software and any accompanying information is for suggestion only.
 * It does not modify Microchip's standard warranty for its products.
 * You agree that you are solely responsible for testing the software and
 * determining its suitability.  Microchip has no obligation to modify,
 * test, certify, or support the software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE, OR ITS INTERACTION WITH
 * MICROCHIP PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY
 * APPLICATION.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL,
 * PUNITIVE, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF
 * ANY KIND WHATSOEVER RELATED TO THE USE OF THIS SOFTWARE, THE
 * motorBench(R) DEVELOPMENT SUITE TOOL, PARAMETERS AND GENERATED CODE,
 * HOWEVER CAUSED, BY END USERS, WHETHER MICROCHIP'S CUSTOMERS OR
 * CUSTOMER'S CUSTOMERS, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES OR THE DAMAGES ARE FORESEEABLE. TO THE
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 * CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
 * OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
 * SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF
 * THESE TERMS.
 *
 * *****************************************************************************/

#include <stdbool.h>
#include "board_service.h"
#include "error_codes.h"
#include "ui.h"
#include "parameters/hal_params.h"
#include "parameters/timing_params.h"

static MCAF_BOARD_DATA board;

/**
 * Initializes the state variables for a given button.
 * @param pButtonData pointer to a BOARD_BUTTON_DATA_T struct
 */
static void MCAF_ButtonInit(volatile BOARD_BUTTON_DATA_T *pButtonData)
{
    pButtonData->buttonState = BOARD_BUTTON_UNPRESSED;
    pButtonData->shortButtonPress = false;
    pButtonData->longButtonPress = false;
    pButtonData->counterC1 = 0;
}

/**
 * Runs the button handler to debounce button inputs and 
 * check for short and long press events.
 * @param pButtonData pointer to a BOARD_BUTTON_DATA_T struct
 * @param rawInput is the raw GPIO signal from the board switch
 */
static void MCAF_ButtonService(volatile BOARD_BUTTON_DATA_T *pButtonData, bool rawInput)
{   
    switch(pButtonData->buttonState)
    {
        default:
        case BOARD_BUTTON_UNPRESSED:
        pButtonData->counterC1++;
        if (rawInput)
        {
            if (pButtonData->counterC1 >= MCAF_BUTTON_DEBOUNCE_TIME)
            {
                pButtonData->buttonState = BOARD_BUTTON_PRESSED;
                pButtonData->counterC1 = 0;
            }
        }
        else
        {
            pButtonData->buttonState = BOARD_BUTTON_UNPRESSED;
            pButtonData->counterC1 = 0;
        }
        break;
        
        case BOARD_BUTTON_PRESSED:
        pButtonData->counterC1++;
        if (pButtonData->counterC1 >= MCAF_BUTTON_LONG_PRESS_TIME)
        {
            pButtonData->longButtonPress = true;
            pButtonData->buttonState = BOARD_BUTTON_LONGPRESS;
        }
        else if (!rawInput)
        {
            pButtonData->shortButtonPress = true;
            pButtonData->counterC1 = 0;
            pButtonData->buttonState = BOARD_BUTTON_UNPRESSED;
        }
        break;
        
        case BOARD_BUTTON_LONGPRESS:
        if (!rawInput)
        {
            pButtonData->counterC1 = 0;
            pButtonData->buttonState = BOARD_BUTTON_UNPRESSED;
        }
        break;
    }
}

void MCAF_BoardServiceInit(void)
{
    board.configComplete = true;
    board.runtimeState = HAL_BOARD_READY;
    board.isrCount = 0;
    MCAF_ButtonInit(&board.sw1);
    MCAF_ButtonInit(&board.sw2);
}

void MCAF_BoardServiceStepMain(void)
{
    
}

void MCAF_BoardServiceTasks(void)
{
    MCAF_ButtonService(&board.sw1,HAL_ButtonGp1RawInput());
    MCAF_ButtonService(&board.sw2,HAL_ButtonGp2RawInput());
}

bool MCAF_ButtonGp1_EventGet(void)
{
    return board.sw1.shortButtonPress;
}

bool MCAF_ButtonGp2_EventGet(void)
{
    if (HAL_hasTwoButtons())
    {
        return board.sw2.shortButtonPress;
    }
    else
    {
        return board.sw2.longButtonPress;
    }
}

void MCAF_ButtonGp1_EventClear(void)
{
    board.sw1.shortButtonPress = false;
}

void MCAF_ButtonGp2_EventClear(void)
{
    if (HAL_hasTwoButtons())
    {
        board.sw2.shortButtonPress = false;
    }
    else
    {
        board.sw2.longButtonPress = false;
    }
}

void MCAF_BootstrapChargeInit(void)
{
    board.bootstrapDutycycle[0] = 0;
    board.bootstrapDutycycle[1] = 0;
    board.bootstrapDutycycle[2] = 0;
    board.delayCount = 0;
    board.bootstrapState = 0;
}

bool MCAF_BootstrapChargeStepIsr(void)
{
    bool returnState = false;
    
    switch(board.bootstrapState)
    {
        case MCBS_IDLE_START:
            HAL_PWM_Outputs_Disable();
            board.bootstrapDutycycle[0] = HAL_PARAM_PWM_PERIOD_COUNTS;
            board.bootstrapDutycycle[1] = HAL_PARAM_PWM_PERIOD_COUNTS;
            board.bootstrapDutycycle[2] = HAL_PARAM_PWM_PERIOD_COUNTS;
            board.delayCount = MCAF_BOARD_BOOTSTRAP_INITIAL_DELAY;
            board.bootstrapState = MCBS_WAIT0;
            break;
            
        case MCBS_WAIT0:
            /* Wait for a preset duration of time */
            if (board.delayCount == 0)
            {
                /* Override all three motor phases to LOW state and
                 * reset all bootstrap related state variables */
                HAL_PWM_UpperTransistorsOverride_Low();
                HAL_PWM_LowerTransistorsOverride_Disable();                
                
                board.bootstrapState = MCBS_PHASE_A_CHARGING;
            }
            break;

        case MCBS_PHASE_A_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */
            if (board.delayCount == 0)
            {
                board.delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (board.bootstrapDutycycle[0] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    board.bootstrapDutycycle[0]--;
                }
                else
                {
                    board.delayCount = MCAF_BOARD_BOOTSTRAP_PHASE_DELAY;
                    board.bootstrapState = MCBS_WAIT1;
                }
            }
            break;
            
        case MCBS_WAIT1:
            /* Wait for a preset duration of time */
            if (board.delayCount == 0)
            {
                board.bootstrapState = MCBS_PHASE_B_CHARGING;
            }
            break;
            
        case MCBS_PHASE_B_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */            
            if (board.delayCount == 0)
            {
                board.delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (board.bootstrapDutycycle[1] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    board.bootstrapDutycycle[1]--;
                }
                else
                {
                    board.delayCount = MCAF_BOARD_BOOTSTRAP_PHASE_DELAY;
                    board.bootstrapState = MCBS_WAIT2;
                }
            }
            break;
            
        case MCBS_WAIT2:
            /* Wait for a preset duration of time */
            if (board.delayCount == 0)
            {
                board.bootstrapState = MCBS_PHASE_C_CHARGING;
            }
            break;

        case MCBS_PHASE_C_CHARGING:
            /* Increment the phase duty cycle at a controlled rate till
             * it reaches a preset value and then proceed to the next state */            
            if (board.delayCount == 0)
            {
                board.delayCount = MCAF_BOARD_BOOTSTRAP_SEQUENCE_DELAY;
                if (board.bootstrapDutycycle[2] > (HAL_PARAM_PWM_PERIOD_COUNTS-HAL_PARAM_MIN_LOWER_DUTY_COUNTS))
                {
                    board.bootstrapDutycycle[2]--;
                }
                else
                {
                    board.bootstrapState = MCBS_BOOTSTRAP_COMPLETE;
                }
            }
            break;
            
        case MCBS_BOOTSTRAP_COMPLETE:
            /* Bootstap sequence is complete, wait in this state */
            returnState = true;
            break;
    }
    HAL_PWM_DutyCycle_Set(board.bootstrapDutycycle);
    
    if (board.delayCount > 0)
    {
        board.delayCount--;
    }
    
    return returnState;
}